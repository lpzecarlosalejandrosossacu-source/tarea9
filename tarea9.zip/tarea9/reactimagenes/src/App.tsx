import React, { useEffect, useState } from "react"
import "aframe"
import { Entity, Scene } from "aframe-react"

const App: React.FC = () => {
  const [isBlue, setIsBlue] = useState(false)

  useEffect(() => {
    const box = document.getElementById("myBox")
    if (box) {
      const handleClick = () => setIsBlue(prev => !prev)
      box.addEventListener("click", handleClick)

      return () => {
        box.removeEventListener("click", handleClick)
      }
    }
  }, [])

  return (
    <Scene>
      {/* Fondo */}
      <Entity
        primitive="a-sky"
        src="/alessandro-erbetta-mpWPcRT9D1E-unsplash.jpg"
        rotation="0 -90 0"
      />

      {/* Cámara y cursor */}
      <Entity primitive="a-camera" position="0 1.6 0">
        <Entity primitive="a-cursor" />
      </Entity>

      {/* Texto de bienvenida */}
      <Entity
        text={{
          value: "Bienvenido a Sistemas- sossa",
          align: "center",
          color: "yellow",
          width: 6,
        }}
        position="0 3 -3"
      />

      {/* Primer cuadrado interactivo */}
      <Entity
        id="myBox"
        primitive="a-box"
        position="0 1.5 -3"
        depth="1"
        height="1"
        width="1"
        color={isBlue ? "blue" : "white"}
      />

      {/* Segundo cuadrado fijo */}
      <Entity
        primitive="a-box"
        position="2 1.5 -3"
        depth="1"
        height="1"
        width="1"
        color="blue"
      />
      <Entity
        text={{ value: "Login", align: "center", color: "white" }}
        position="2 1.5 -2.4"
      />
    </Scene>
  )
}

export default App
